package main;

public final class Constants {
    public static final int MAX_SIZE_5 = 5;
    public static final int FORWARD_TIME = 90;
    public static final int BACKWARD_TIME = 90;

    private Constants() {
    }
}
